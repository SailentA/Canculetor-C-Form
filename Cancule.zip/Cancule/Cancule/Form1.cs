﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cancule
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string a,op,b;
        int res;
        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "0")
                textBox1.Clear();
            if(res==1)
            {
                textBox1.Text = button1.Text;
                res = 0;
            }
            else
                textBox1.Text += button1.Text;
        //    a += button1.Text;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            if (res == 1)
            {
                textBox1.Text = button6.Text;
                res = 0;
            }
            else
                textBox1.Text += button6.Text;
         //   a += button6.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            if (res == 1)
            {
                textBox1.Text = button7.Text;
                res = 0;
            }
            else
                textBox1.Text += button7.Text;
        //    a += button7.Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button2.Text;
                res = 0;
            }
            else
                textBox1.Text += button2.Text;
        //    a += button2.Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button5.Text;
                res = 0;
            }
            else
                textBox1.Text += button5.Text;
        //    a += button5.Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button9.Text;
                res = 0;
            }
            else
                textBox1.Text += button9.Text;
        //    a += button9.Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button3.Text;
                res = 0;
            }
            else
                textBox1.Text += button3.Text;
         //   a += button3.Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button4.Text;
                res = 0;
            }
            else
                textBox1.Text += button4.Text;
         //   a += button4.Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            if (res == 1)
            {
                textBox1.Text = button8.Text;
                res = 0;
            }
            else
                textBox1.Text += button8.Text;
        //    a += button8.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            if (res == 1)
            {
                textBox1.Text = button10.Text;
                res = 0;
            }
            else
            textBox1.Text += button10.Text;
        //    a += button10.Text;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            textBox1.Text = "0";
            a = " 0";
            label1.Text = a;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            

        }
        
        private void button18_Click(object sender, EventArgs e)
        {

            int a;
            a = (int)MessageBox.Show("Do You Want Turn On/Off?","r u sure", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (a == 6)
            {
                groupBox1.Enabled = true;
            }
            if(a!=6)
            {
                groupBox1.Enabled = false;
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            a = textBox1.Text;
            op = "*";
            if (textBox1.Text != "0")
            {
                textBox1.Text = "0";
            }
            label1.Text = a;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            a = textBox1.Text;
            op = "-";
            if (textBox1.Text != "0")
            {
                textBox1.Text = "0";
            }
            label1.Text = a;
        }

        private void button17_Click(object sender, EventArgs e)
        {

            a = textBox1.Text;
            op = "+";
            if (textBox1.Text != "0")
            {
                textBox1.Text = "0";
            }
            label1.Text = a;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            
            a = textBox1.Text;
            op = "/";
            if (textBox1.Text != "0")
            {
                textBox1.Text = "0";
            }
            label1.Text = a;



        }

        private void button15_Click(object sender, EventArgs e)
        {
            b = textBox1.Text;
            if (op == "/")
            {
                textBox1.Text = (int.Parse(a) / int.Parse(b)).ToString();

            }
            if (op == "*")
            {
                textBox1.Text = (int.Parse(a) * int.Parse(b)).ToString();

            }
            if (op == "+")
            {
                textBox1.Text = (int.Parse(a) + int.Parse(b)).ToString();

            }
            if (op == "-")
            {

                textBox1.Text = (int.Parse(a) - int.Parse(b)).ToString();

            }
            res = 1;
            label1.Text = textBox1.Text;
        }
    }
}
